from setuptools import setup

setup(
    name='Pku_module',
    version='0.2',
    description='Utilidades para actualizacion de modulos y paquetes.',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['Pku_module']
)