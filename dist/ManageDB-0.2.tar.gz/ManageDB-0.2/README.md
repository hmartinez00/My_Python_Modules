# My_Python_Modules
My python modules collection.

Paquete: TradingPackage-0.1
Contiene modulo para el manejo de objetos de la Api de Binance, modulo para gestion de indicadores, y modulo para gestion de estrategias.

Paquete: General_Utilities-0.1
Subrutinas generales.


Pasos para creacion o actualizacion desde PC-1:
<!-- Directorio donde se encuentra el setup.py -->
$ cd [directorio-raiz-del-proyecto]
$ python setup.py sdist

Pasos de intalacion o actualizacion desde PC-2:
$ cd ~/dist
$ pip install {Package_Name}-{version}.tar.gz

