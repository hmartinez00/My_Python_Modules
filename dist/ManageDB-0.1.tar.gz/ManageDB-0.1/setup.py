from setuptools import setup

setup(
    name='ManageDB',
    version='0.1',
    description='Herramientas para gestion de Bases de Datos SQL.',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['ManageDB']
)