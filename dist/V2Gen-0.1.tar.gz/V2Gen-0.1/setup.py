from setuptools import setup

setup(
    name='V2Gen',
    version='0.1',
    description='Paquete ligero de modulos para generacion VRSS',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['V2Gen']
)