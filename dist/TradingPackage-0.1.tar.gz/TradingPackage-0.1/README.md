# My_Python_Modules
My python modules collection.

Paquete: TradingPackage-0.1
Contiene modulo para el manejo de objetos de la Api de Binance, modulo para gestion de indicadores, y modulo para gestion de estrategias.



Pasos de intalacion o actualizacion desde PC-2:
$ cd ~/dist
$ pip install TradingPackage-0.1.tar.gz

Pasos para creacion o actualizacion desde PC-1:
<!-- Directorio donde se encuentra el setup.py -->
$ cd [directorio-raiz-del-proyecto]
$ python setup.py sdist
