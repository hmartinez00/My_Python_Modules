from setuptools import setup

setup(
    name='Package_update_module',
    version='0.1',
    description='Utilidades para actualizacion de modulos y paquetes.',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['Package_update_module']
)