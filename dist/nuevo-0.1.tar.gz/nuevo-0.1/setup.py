from setuptools import setup

setup(
    name='nuevo',
    version='0.1',
    description='aa',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['nuevo']
)