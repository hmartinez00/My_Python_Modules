# Datos de telegram

# https://api.telegram.org/bot5522228971:AAE0YIZt7yCH7rhXXQEuRVsh1VsoF8I-vDA/getUpdates

TELEGRAM_URL = 'https://api.telegram.org/bot'
TELEGRAM_CHAT_ID = 1580008489
TELEGRAM_TOKEN = '5522228971:AAE0YIZt7yCH7rhXXQEuRVsh1VsoF8I-vDA'