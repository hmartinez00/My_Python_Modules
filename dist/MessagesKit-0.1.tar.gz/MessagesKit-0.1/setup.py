from setuptools import setup

setup(
    name='MessagesKit',
    version='0.1',
    description='Utilidades para mensajeria.',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['MessagesKit']
)