from setuptools import setup

setup(
    name='VRSS-2_Generate',
    version='0.1',
    description='Utilidades para generacion de archivos de planes de misiones satelitales VRSS para el Subsistema de Gestion y Operaciones ABAE.',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['VRSS-2_Generate']
)