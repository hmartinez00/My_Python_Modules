from setuptools import setup

setup(
    name='Eliezer',
    version='0.1',
    description='Asistente dirigido por reconocimiento de voz.',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['Eliezer']
)