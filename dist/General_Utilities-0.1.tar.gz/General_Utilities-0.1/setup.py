from setuptools import setup

setup(
    name='General_Utilities',
    version='0.1',
    description='Subrutinas generales.',
    author='Hector Martinez',
    author_email='hectoralonzomartinez00@gmail.com',
    url='',
    packages=['General_Utilities']
)